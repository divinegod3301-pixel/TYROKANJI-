package com.kanjiwidget.widget

import androidx.compose.runtime.Composable
import androidx.glance.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.sp
import com.kanjiwidget.data.KanjiRepository

class KanjiAppWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: android.content.Context, id: GlanceId) {
        provideContent {
            WidgetContent()
        }
    }
}

@Composable
private fun WidgetContent() {
    val item = KanjiRepository.items.first()
    Column(
        modifier = GlanceModifier.fillMaxSize().padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(item.character, style = TextStyle(fontSize = 38.sp))
        Text("${item.hiragana} • ${item.romaji}", style = TextStyle(fontSize = 14.sp))
        Text(item.meaning, style = TextStyle(fontSize = 14.sp))
    }
}
