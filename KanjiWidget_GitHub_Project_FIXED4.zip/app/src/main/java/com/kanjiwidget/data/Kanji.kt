package com.kanjiwidget.data

data class Kanji(
    val character: String,
    val hiragana: String,
    val romaji: String,
    val meaning: String,
    val jlpt: String = "N5",
    val example: String = ""
)
