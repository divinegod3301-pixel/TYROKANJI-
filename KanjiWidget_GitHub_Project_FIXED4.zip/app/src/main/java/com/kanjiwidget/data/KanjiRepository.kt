package com.kanjiwidget.data

object KanjiRepository {
    val items = listOf(
        Kanji("人", "ひと", "hito", "person", example = "人（ひと）"),
        Kanji("日", "ひ", "hi", "day / sun", example = "日本（にほん）"),
        Kanji("一", "いち", "ichi", "one", example = "一つ（ひとつ）"),
        Kanji("二", "に", "ni", "two", example = "二つ（ふたつ）"),
        Kanji("三", "さん", "san", "three", example = "三つ（みっつ）"),
        Kanji("四", "よん", "yon", "four", example = "四つ（よっつ）"),
        Kanji("五", "ご", "go", "five", example = "五つ（いつつ）"),
        Kanji("六", "ろく", "roku", "six", example = "六つ（むっつ）"),
        Kanji("七", "なな", "nana", "seven", example = "七つ（ななつ）"),
        Kanji("八", "はち", "hachi", "eight", example = "八つ（やっつ）"),
        Kanji("九", "きゅう", "kyuu", "nine", example = "九つ（ここのつ）"),
        Kanji("十", "じゅう", "juu", "ten", example = "十（じゅう）"),
        Kanji("大", "おお", "oo", "big", example = "大きい（おおきい）"),
        Kanji("小", "ちい", "chii", "small", example = "小さい（ちいさい）"),
        Kanji("上", "うえ", "ue", "up / above", example = "上（うえ）"),
        Kanji("下", "した", "shita", "down / below", example = "下（した）"),
        Kanji("中", "なか", "naka", "inside / middle", example = "中（なか）"),
        Kanji("山", "やま", "yama", "mountain", example = "山（やま）"),
        Kanji("川", "かわ", "kawa", "river", example = "川（かわ）"),
        Kanji("水", "みず", "mizu", "water", example = "水（みず）")
    )
}
