package com.kanjiwidget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kanjiwidget.data.Kanji
import com.kanjiwidget.data.KanjiRepository

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KanjiWidgetApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KanjiWidgetApp() {
    MaterialTheme {
        var selected by remember { mutableStateOf<Kanji?>(null) }
        val kanji = KanjiRepository.items

        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Kanji Widget") })
            }
        ) { padding ->
            if (selected == null) {
                LazyColumn(
                    modifier = Modifier.padding(padding).fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            "Learn Japanese Kanji",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("${kanji.size} starter Kanji loaded • Offline")
                    }
                    items(kanji) { item ->
                        ElevatedCard(
                            onClick = { selected = item },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                Modifier.padding(18.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(item.character, fontSize = 42.sp)
                                Spacer(Modifier.width(18.dp))
                                Column {
                                    Text(item.meaning, fontWeight = FontWeight.Bold)
                                    Text("${item.hiragana} • ${item.romaji}")
                                }
                            }
                        }
                    }
                }
            } else {
                KanjiDetail(selected!!) { selected = null }
            }
        }
    }
}

@Composable
fun KanjiDetail(item: Kanji, back: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TextButton(onClick = back) { Text("← Back") }
        Spacer(Modifier.height(20.dp))
        Text(item.character, fontSize = 110.sp)
        Text(item.meaning, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("${item.hiragana} • ${item.romaji}", fontSize = 20.sp)
        Spacer(Modifier.height(18.dp))
        Text("JLPT ${item.jlpt}", fontSize = 18.sp)
        Text("Example: ${item.example}")
    }
}
