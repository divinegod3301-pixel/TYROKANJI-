# Kanji Widget

A starter Android app for Japanese Kanji learning with a home-screen widget.

## Current features

- Kotlin + Jetpack Compose
- Material 3
- Offline Kanji repository
- Kanji detail screen
- Glance home-screen widget
- GitHub Actions APK build
- Starter N5 Kanji data

## Open in Android Studio

1. Create a GitHub repository.
2. Upload the contents of this project.
3. Open the repository in Android Studio.
4. Let Gradle sync.
5. Run the `app` configuration on an Android device/emulator.

## Build APK on GitHub

Go to:

`Actions` → `Build TYRO KANJI APK` → `Run workflow`

After the workflow finishes, download the artifact named:

`tyro-kanji-debug-apk`

## Important

This is the first working foundation, not the final 320-Kanji production release. The repository is intentionally structured so the full Kanji dataset, SRS, quizzes, settings, favorites, and widget rotation can be added next.


## Build fix

The GitHub Actions workflow uses Gradle 8.11.1 directly and JDK 17. The Android module explicitly sets both Java and Kotlin JVM targets to 17, preventing the Kotlin JVM-target validation error that can occur when the targets are different.
