package com.tyro.kanji

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.TaskStackBuilder
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit
import kotlin.random.Random

object NotificationScheduler {
    private const val WORK = "tyro_kanji_two_hour_learning"
    private const val CHANNEL = "tyro_learning"

    fun schedule(context: Context) {
        createChannel(context)
        val request = PeriodicWorkRequestBuilder<LearningNotificationWorker>(2, TimeUnit.HOURS)
            .setInitialDelay(2, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK, ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "TYRO KANJI learning", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Gentle TYRO KANJI learning reminders"
                }
            )
        }
    }
}

class LearningNotificationWorker(
    context: Context, params: WorkerParameters
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val messages = listOf(
            "A tiny Kanji break? 🌸",
            "Ready for one more Kanji? ✨",
            "Your Japanese journey is waiting 📚",
            "Two minutes of Kanji can go a long way 🌸",
            "おつかれさま！ Let’s review a little."
        )
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val openApp = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = TaskStackBuilder.create(applicationContext)
            .addNextIntentWithParentStack(openApp)
            .getPendingIntent(
                9100,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )

        val notification = NotificationCompat.Builder(applicationContext, "tyro_learning")
            .setSmallIcon(com.tyro.kanji.R.drawable.tyro_icon)
            .setContentTitle("TYRO KANJI")
            .setContentText(messages[Random.nextInt(messages.size)])
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()
        if (Build.VERSION.SDK_INT < 33 ||
            applicationContext.checkSelfPermission("android.permission.POST_NOTIFICATIONS") ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            manager.notify(3200 + Random.nextInt(100), notification)
        }
        return Result.success()
    }
}
